import React from 'react';
import  about from  '../css/about.css';
const About = () =>
{
        return(


            <div>
                <div className="about">
                <h1>About page</h1>
                </div>
            </div>
        )

}

export default About