import React from 'react';
import menu from '../css/menu.css';
const Menu = () =>
{
        return(


            <div>
                <div className="menu">
                    <div className="home"><a href="/">home</a></div>
                    <div className="about"><a href="About">about</a></div>
                    <div className="contact"><a href="Contact">contact</a></div>
                </div>
            </div>
        )

}

export default Menu