import React from 'react';
import contact from '../css/contact.css';
const Contact = () =>
{
        return(


            <div>
                <div className="contact">
                <h1>contact page</h1>
                </div>
                
            </div>
        )

}

export default Contact